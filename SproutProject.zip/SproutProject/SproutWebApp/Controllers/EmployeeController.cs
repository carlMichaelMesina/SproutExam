﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using SproutClass;
using System.Linq;
using System;

namespace SproutWebApp.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult ViewAllEmployees()
        {
            List<Models.Employee> employeeList = HttpContext.Session.GetObjectFromJson<List<Models.Employee>>("EmployeeList") ?? new List<Models.Employee>();

            //if (employeeList.Count == 0)
            //{
            //    employeeList = new List<Models.Employee>
            //    {
            //            new Models.Employee() { EmployeeId = 1, Name = "John", EmployeeType = "R", Status = "P", Birthdate= System.DateTime.Parse("07/13/1994"), TIN = "12345678", BasicSalary = 20000,Tax = 0.12 } ,
            //            new Models.Employee() { EmployeeId = 2, Name = "James", EmployeeType = "C", Status = "P", Birthdate=System.DateTime.Parse("07/13/1994"), TIN = "12345678", BasicSalary = 500,Tax =0} ,
            //            new Models.Employee() { EmployeeId = 3, Name = "Harold", EmployeeType = "R", Status = "A", Birthdate=System.DateTime.Parse("07/13/1994"), TIN = "12345678", BasicSalary = 45000,Tax = 0.12}
            //    };

            //    HttpContext.Session.SetObjectAsJson("EmployeeList", employeeList);
            //}

            return View(employeeList);
        }
        public IActionResult AddEmployee()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SaveEmployee(Models.Employee employee)
        {
            if (!ModelState.IsValid)
            {
                return View("AddEmployee");
            }

            List<Models.Employee> employeeList = HttpContext.Session.GetObjectFromJson<List<Models.Employee>>("EmployeeList") ?? new List<Models.Employee>();
            Models.Employee Employee = new Models.Employee();

            Employee.EmployeeId = employeeList.Count+1;
            Employee.Name = employee.Name;
            Employee.Birthdate = employee.Birthdate;
            Employee.TIN = employee.TIN;
            Employee.BasicSalary = employee.BasicSalary;
            Employee.EmployeeType = employee.EmployeeType;
            Employee.Status = "P";

            if(employee.EmployeeType == "R")
            {
                Employee.Tax = 0.12;
            }
            else
            {
                Employee.Tax = 0;
            }
            employeeList.Add(Employee);

            HttpContext.Session.SetObjectAsJson("EmployeeList", employeeList);

            return RedirectToAction("ViewAllEmployees","Employee");
        }
        public IActionResult CalculateEmployeeSalary(long employeeID)
        {
            
            List<Models.Employee> employeeList = HttpContext.Session.GetObjectFromJson<List<Models.Employee>>("EmployeeList") ?? new List<Models.Employee>() ;
            return View(employeeList.Where(row => row.EmployeeId == employeeID).FirstOrDefault());
        }
        [HttpPost]
        public IActionResult ApprovedEmployeeSalary(Models.Employee employee, long employeeID)
        {

            List<Models.Employee> employeeList = HttpContext.Session.GetObjectFromJson<List<Models.Employee>>("EmployeeList") ?? new List<Models.Employee>();
            var Employee = employeeList.FirstOrDefault(x => x.EmployeeId == employeeID);

            try
            {
                if (Employee.EmployeeType == "R")
                {
                    Employee.Absences = employee.Absences;
                    Employee.ComputedSalary = Employee.BasicSalary - (Employee.Absences * (Employee.BasicSalary / 22)) - (Employee.BasicSalary * Employee.Tax);
                }
                else
                {
                    Employee.Attendance = employee.Attendance;
                    Employee.ComputedSalary = Employee.BasicSalary * Employee.Attendance;
                }



                Employee.Status = "A";


                HttpContext.Session.SetObjectAsJson("EmployeeList", employeeList);

                return View(Employee);
            }
            catch(Exception ex)
            {
                return View("CalculateEmployeeSalary", employeeList);
            }


            
        }
        public IActionResult ReviewEmployeeSalary(long employeeID)
        {

            List<Models.Employee> employeeList = HttpContext.Session.GetObjectFromJson<List<Models.Employee>>("EmployeeList") ?? new List<Models.Employee>();
            var Employee = employeeList.FirstOrDefault(x => x.EmployeeId == employeeID);
            return View("ApprovedEmployeeSalary", Employee);
        }
    }
}
